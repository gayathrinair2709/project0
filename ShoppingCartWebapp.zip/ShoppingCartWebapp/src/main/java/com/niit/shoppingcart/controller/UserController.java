
	package com.niit.shoppingcart.controller;

	



import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestParam;
	import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;


	@Controller
	public class UserController {
		Logger log=LoggerFactory.getLogger(UserController.class);
	    @Autowired
	    UserDAO userDAO;
	    @Autowired
	    User user;
		@RequestMapping("/login")
	    public ModelAndView login(@RequestParam(value="id") String userid,@RequestParam(value="password" )String password,HttpSession session)
	    {
	    	ModelAndView mv = new ModelAndView("home");
	    	String msg;
	    	if(userDAO.isValidUser(userid,password)==null)
	    	{
	    		msg="Invalid user!!!.... Please try again...";
	    	}
	    	else
	    	{
	    		if(user.getRole().equals("Role_Admin"))
	    		{
	    			mv=new ModelAndView("adminpage");
	    			}
	    	}
	     session.setAttribute("WelcomeMsg",user.getName())  ;
	     session.setAttribute("UserId", user.getId());
	     return mv;
	    }
		@RequestMapping("/register")
	    public ModelAndView register()
	    {}
	
	
	}


