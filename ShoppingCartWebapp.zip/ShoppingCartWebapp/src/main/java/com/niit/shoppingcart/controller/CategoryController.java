package com.niit.shoppingcart.controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

@Controller
public class CategoryController {
private static Logger Log= LoggerFactory.getLogger(CategoryController.class);
@Autowired
private CategoryDAO categoryDAO;
@Autowired
private Category category;
@RequestMapping(value="/caegories",method=RequestMethod.GET)
public String listCategories(Model model)
{
	Log.debug("Starting  of the method listCategories");
	model.addAttribute("category", category);
	model.addAttribute("categoryList",this.categoryDAO.list());
	Log.debug("End of the method listCategories");
	return "category";
	}
@RequestMapping(value="/category/add",method=RequestMethod.POST)
public String addCategory(@ModelAttribute("category") Category category)
{
	Log.debug("Starting  of the method addCategory");
	categoryDAO.save(category);
	Log.debug("Ending of the method addCategory");
	return "category";
	}
@RequestMapping("/category/remove/{id}")
public ModelAndView deleteCategory(@PathVariable("id") String id) throws Exception
{   category=categoryDAO.get(id);
	ModelAndView mv = new ModelAndView("category");
	
	if(category==null)
	{mv.addObject("error message","could not delete the category");
	}
	else
		categoryDAO.delete(category);
	

return mv;
}
@RequestMapping("/category/edit/{id}")
public String edutcategory(@PathVariable("id")String id,Model model)
{
	Log.debug("Starting of the method editcategory");
	Log.info("Category id going to be edited is:"+id);
	category=categoryDAO.get(id);
	model.addAttribute("catgory",category);
	model.addAttribute("categoryList",categoryDAO.list());
	Log.debug("end of the method edit category");
	return "category";
	}
}

