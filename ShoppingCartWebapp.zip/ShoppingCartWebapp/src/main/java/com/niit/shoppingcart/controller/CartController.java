package com.niit.shoppingcart.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Product;

public class CartController {
@Autowired
private CartDAO cartDAO;
@Autowired
private Cart cart;
@Autowired
private ProductDAO productDAO;
@RequestMapping(value="/myCart",method=RequestMethod.GET)
public String myCart(Model model,HttpSession session)
{
	model.addAttribute("cart",new Cart());
	String loggedInUserid=(String)session.getAttribute("loggedInUserId");
	model.addAttribute("cartList", cartDAO.list(loggedInUserid));
	model.addAttribute("totalAmount", cartDAO.getTotalAmount(loggedInUserid));
	model.addAttribute("displayCart","true");
	return "/home";
	
	}
@RequestMapping(value="/myCart/add/{id}",method=RequestMethod.GET)

public String addToCart(@PathVariable("id") String id,HttpSession session)
{
	Product product=productDAO.get(id);
	cart.setPrice(product.getPrice());
	cart.setProductNAme(product.getName);
	cart.setQuantity(1);
	String loggedInUserid
	
	}
}
