package com.niit.shop.controller;
import com.niit.shop.dao.CategoryDAO;
import com.niit.shop.dao.ProductDAO;
import com.niit.shop.dao.SupplierDAO;
import com.niit.shop.model.Category;
import com.niit.shop.model.Product;
import com.niit.shop.model.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class AdminController {


@Autowired
private Category category;


@Autowired
private CategoryDAO categoryDAO;

@Autowired
private Product product;


@Autowired
private ProductDAO productdao;
@Autowired
private Supplier supplier;


@Autowired
private SupplierDAO supplierdao;

@RequestMapping("/manageCategories")
public ModelAndView manageCategories(){
	ModelAndView mv= new ModelAndView("CategoryList");
	mv.addObject("category",category);
	return mv;
	
}	@RequestMapping("/manageproduct")
	public ModelAndView manageProduct(){
		ModelAndView mv= new ModelAndView("ProductList");
		mv.addObject("product",product);
		return mv;
}
		@RequestMapping("/managesupplier")
		public ModelAndView managesupplier(){
			ModelAndView mv= new ModelAndView("SupplierList");
			mv.addObject("supplier",supplier);
			return mv;
				
}
}


