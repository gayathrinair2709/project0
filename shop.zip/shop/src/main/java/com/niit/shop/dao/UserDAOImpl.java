package com.niit.shop.dao;




import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shop.model.User;


@Repository("usersDAO")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;


	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<User> list() {
		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) sessionFactory.getCurrentSession().createCriteria(User.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void saveOrUpdate(User user) {
		user.setRole("ROLE_USER");
		user.setEnabled(true);
		sessionFactory.getCurrentSession().saveOrUpdate(user);

	}

	/*
	 * @Transactional public void saveOrUpdate(User userDetails) {
	 * sessionFactory.getCurrentSession().saveOrUpdate(userDetails); }
	 */

	@Transactional
	public void delete(String username) {
		User user = new User();
		user.setUsername(username);
		
		sessionFactory.getCurrentSession().delete(user);
	}

	@Transactional
	public User get(String username) {
		String hql = "from Users where username=" + username;
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) query.list();

		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	public boolean equals(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isValidUser1(String username, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Transactional
	public boolean isValidUser(String username, String password) {
		System.out.println("dao impl");
		String hql = "from Users where username= '" + username + "' and " + " password ='" + password + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) query.list();

		if (list != null && !list.isEmpty()) {
			return true;
		}

		return false;
	}

	
	
	
}
