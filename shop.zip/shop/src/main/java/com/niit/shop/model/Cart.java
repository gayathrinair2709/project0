package com.niit.shop.model;

public class Cart {

}
