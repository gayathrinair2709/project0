package com.niit.shop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shop.dao.UserDAO;
import com.niit.shop.model.User;

import javax.servlet.http.HttpSession;



@Controller
public class HomeController {

	@Autowired
	User user;
	@Autowired(required=true)
	UserDAO userDAO;
	
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session)
	{
	ModelAndView mv = new ModelAndView("home");

	return mv;
	}
	@RequestMapping("/Register")
public ModelAndView registerhere()
{
	ModelAndView mv = new ModelAndView("Register");
	mv.addObject("userDetails", user);
	mv.addObject("isUserClickedRegisterHere", "true");
	return mv;
}

@RequestMapping("/LoginHere")
public ModelAndView loginHere()
{
	ModelAndView mv = new ModelAndView("Login");
	mv.addObject("userDetails", user);
	mv.addObject("isUserClickedLoginHere", "true");
	
	return mv;
}
	
@RequestMapping(value="/RegisterSuccess",method = RequestMethod.POST)
public ModelAndView registerUser(@ModelAttribute User user)
{
	ModelAndView mv = new ModelAndView("Login");
	if(userDAO.get(user.getUserid())==null)
	{
		userDAO.save(user);
		mv.addObject("msg","you are successfully register");
	}
	else
	{
		mv.addObject("msg", "user exist with this id");
	}
	
	mv.addObject("isUserClickedSubmit", "true");
	return mv;
}

}


