
	package com.niit.shoppingcart.model;

	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Table;

	@Entity
	@Table(name="User")//if table name and domain class have same name,the no need to mention here
	public class User {
		
		@Id  //primary key in the table
		private String id;
		
		private String Name;
		private String Email;
		private String Password;
		private String Phnumber;
		private String Role;
		
		public String getEmail() {
			return Email;
		}
		public void setEmail(String email) {
			Email = email;
		}
		public String getRole() {
			return Role;
		}
		public void setRole(String role) {
			Role = role;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public String getPassword() {
			return Password;
		}
		public void setPassword(String password) {
			Password = password;
		}
		public String getPhnumber() {
			return Phnumber;
		}
		public void setPhnumber(String phnumber) {
			Phnumber = phnumber;
		}
		
		

	}

