
	package com.niit.shoppingcart.model;

	import javax.persistence.Entity;
	import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

	@Entity
	@Table(name=" Product")//if table name and domain class have same name,the no need to mention here
	public class Product {
		/**id,name and description are in the table**/
		@Id  //primary key in the table
		private String id;
		private String Name;
		private double Price;
		private  String Description;
		@ManyToOne
		@JoinColumn(name="category_id", updatable = false,insertable =false)
		private Category category;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public double getPrice() {
			return Price;
		}
		public void setPrice(double price) {
			Price = price;
		}
		public String getDescription() {
			return Description;
		}
		public void setDescription(String description) {
			Description = description;
		}
		
		

	}

