package com.niit.shoppingcart.dao;

public interface CartDAO {

}
