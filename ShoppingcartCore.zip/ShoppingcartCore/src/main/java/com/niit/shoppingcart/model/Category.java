
	package com.niit.shoppingcart.model;

	import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

	@Entity
	@Table(name="Category")
	//if table name and domain class have same name,the no need to mention here
	@Component
	public class Category {
		/**id,name and description are in the table**/
		@Id  //primary key in the table
		private String Id;
		@Column
		private String Name;
		@Column
		private  String description;
		private List<Product> products;
		@OneToMany(mappedBy="category",fetch=FetchType.EAGER)
	
		
		public String getId() {
			return Id;
		}
		public void setId(String Id) {
			this.Id = Id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		//public List<Product> getProducts() {
		//	return products;
		//}
		//public void setProducts(List<Product> products) {
		//	this.products = products;
		//}
		
		

	}

