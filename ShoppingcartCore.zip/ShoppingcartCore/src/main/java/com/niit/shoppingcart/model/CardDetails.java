package com.niit.shoppingcart.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.stereotype.Component;
@Entity
@Component

public class CardDetails implements Serializable{
	private static final long serialVersionUID=1L;
	@Id
	private String cardDetailId;
	private String customerId;
	@NotBlank(message="Card Number must be entered")
	private String cardNumber;
	@NotBlank(message="Expiry month month mustbe selected")
	private String expiryMonth;
	@NotBlank(message="Expiry year must be selected")
	private String expiryYear;
	@NotBlank(message="CV Number must be entered")
	private String cvNumber;
	@NotBlank(message="Name must be entered")
	private String nameonCard;
	private double totalcost;
	public String getExpiryMonth() {
		return expiryMonth;
	}
	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth = expiryMonth;
	}
	public String getExpiryYear() {
		return expiryYear;
	}
	public void setExpiryYear(String expiryYear) {
		this.expiryYear = expiryYear;
	}
	public String getCvNumber() {
		return cvNumber;
	}
	public void setCvNumber(String cvNumber) {
		this.cvNumber = cvNumber;
	}
	public String getNameonCard() {
		return nameonCard;
	}
	public void setNameonCard(String nameonCard) {
		this.nameonCard = nameonCard;
	}
	public double getTotalcost() {
		return totalcost;
	}
	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}
	public String getCardDetailId() {
		return cardDetailId;
	}
	public void setCardDetailId(String cardDetailId) {
		this.cardDetailId = cardDetailId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

}
