
	package com.niit.shoppingcart.model;

	import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Table;

	@Entity
	@Table(name="Supplier")//if table name and domain class have same name,the no need to mention here
	public class Supplier {
	
		@Id  //primary key in the table
		private String id;
		private String Name;
		private String Address;
		List <Product> productList=new ArrayList<Product>();
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		

	}

