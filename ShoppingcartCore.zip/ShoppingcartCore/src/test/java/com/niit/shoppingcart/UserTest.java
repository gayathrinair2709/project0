package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;

public class UserTest {
	
	
		public static void main(String[] args)
		{
			AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
			context.scan("com.niit.shoppingcart");
			context.refresh();
			UserDAO userDAO = (UserDAO) context.getBean("userDAO");
			
			User user = (User) context.getBean("user");
			
			user.setId("Usha");
			user.setName("Usha Menon");
			user.setEmail("ushamenon@gmail.com");
			user.setPassword("12345");
			user.setPhnumber("9349960540");
			
			
			if(userDAO.save(user) == true)
			{
				System.out.println("User created successfully");
			}
			
			else
			{System.out.println("user not created");
		
			}

	}
}
