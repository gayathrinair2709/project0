package com.niit.shop.controller;

import com.niit.shop.dao.CategoryDAO;
import com.niit.shop.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class CategoryController {
	@Autowired
	private CategoryDAO categoryDAO;
	 @Autowired
	 private Category category;
	 
	 @RequestMapping(value="/categories", method=RequestMethod.GET)
	 public String listCategories(Model model)
	 {
		 model.addAttribute("category",category);
		 model.addAttribute("categoryList",this.categoryDAO.list() );
		 return "Category";
		 
	 }
	 @RequestMapping(value="/category/add", method=RequestMethod.POST)
	 public String addCategory(@ModelAttribute("category")Category category,Model model )
	 {	
		 categoryDAO.save(category);
		 model.addAttribute("categoryList",this.categoryDAO.list() );
		 return "Category";
	 }
	 
	 @RequestMapping("category/remove/{id}")
	 public  ModelAndView deleteCategory(@PathVariable("id") String id,Model model)throws Exception{
		
		 category=categoryDAO.get(id);
		 ModelAndView mv =new ModelAndView("Category");
		 if(category==null)
		 {
			 mv.addObject("errror message","could not delete the category");
		 }
		 else
		 {
			 categoryDAO.delete(category);
		 }
		 model.addAttribute("categoryList",this.categoryDAO.list() );
		 return mv;
	 }
	 @RequestMapping("category/edit/{id}")
		 public ModelAndView editCategory(@ModelAttribute("category")Category category,Model model)
		 {
		 ModelAndView mv=new ModelAndView("Category");
		 if(categoryDAO.get(category.getId())!=null)
		 {
			 categoryDAO.update(category);
			 mv.addObject("message","successfully updated");
		 }
		 else
		 {
			 mv.addObject("error message","could not update the record");
			  
		 }
		 model.addAttribute("categoryList",this.categoryDAO.list() );
		 return mv;
		 		 
	 }

}


